# Extending Models for Printing

This example shows how to add symbols to a model before printing.

# Example Calls

    clingo extend-model-py.lp 0
    clingo extend-model-lua.lp 0
