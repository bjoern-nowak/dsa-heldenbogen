# User Heuristic

This is an example how to implement a simple domain-specific heuristic for the
graph coloring problem.

## Example Calls

    clingo encoding-py.lp instance.lp
    clingo encoding-lua.lp instance.lp
