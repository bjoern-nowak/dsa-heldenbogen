"""
Unit tests for the clingo package.
"""
